import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
                val btnGoogleLogin = findViewById<Button>(R.id.btnGoogleLogin)
                val tvRegister = findViewById<TextView>(R.id.tvRegister)

                btnLogin.setOnClickListener {
            // Handle login logic
        }

        btnGoogleLogin.setOnClickListener {
            // Handle Google login logic
        }

        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }
}
